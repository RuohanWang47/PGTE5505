/*1. Conditions:
Find the current time using the Date() function. Extract the hour from it. Create a condition to check if it's the morning, evening, afternoon or night. 
Use console.log to output an appropriate message. 
*/
let current_time = new Date();
let current_hr = current_time.getHours();
console.log(current_hr);
if(6<=current_hr && current_hr<12){
    console.log("Good Morning!");
}
else if(12<=current_hr && current_hr<18){
    console.log("Good Afternoon!");
}
else if(18<=current_hr && current_hr<21){
    console.log("Good Evening!");
}
else{
    console.log("Good Night!");
}

/*2. Loops:
Use the same random dice generator as above to generate a number between 1 and 6. 
Now create a loop that keep rolling until the number generated is more than 3. 
As soon as you get a number more than three, the loop should end. 
Output how many times the loop ran before it reached this number. 
Be careful with this - if you create a loop that has no way to end (due to a faulty check), it will easily crash your browser!
*/

let min = 1;
let max = 7;
let randomNumber = 0
for(i=0;randomNumber!=3;i++){
    randomNumber = Math.floor(Math.random()*(max-min+1))+min;
}
console.log(i);

/*
3. Loops
Using loops , create a triangular pattern (using console.log statements only for now) like this:
#
##
###
####
*/

for(n=1;n<5;n++){
    switch(n){
        case(1):
        console.log("#");
        break;

        case(2):
        console.log("##");
        break;

        case(3):
        console.log("###");
        break;

        case(4):
        console.log("####");
        break;
    }
}

/* simplified version */
const my_array = ["#","##","###","####"]
for(i=0;i<4;i++){
    console.log(my_array[i]);
}

/*
4. Loops and Conditions:
Using more loops and conditions, create a chess board using # and space ' ' using console.log statements.  
You could consider using a loop inside a loop to create the alternative pattern. A chess board  has  8 x 8 = 64 squares.
*/

for(let y=0;y<9;y++){
let row = ""
for(x=0;x<9;x++){
    row+="#"+" "+" "+" "+" "+" "
}
 console.log(row);
 console.log("");
}
