// Original Code for drawing a chess board
for (let i = 0; i < 8; i++) {
    let row = '';
    for (let j = 0; j < 8; j++) {
      if ((i + j) % 2 === 0) {
        row += '#';
      } else {
        row += ' ';
      }
    }
    console.log(row);
  }

  //make it into a function
  function drawChessboard(){
    for (let i = 0; i < 8; i++) {
        let row = '';
        for (let j = 0; j < 8; j++) {
          if ((i + j) % 2 === 0) {
            row += '#';
          } else {
            row += ' ';
          }
        }
        console.log(row);
  }
}

drawChessboard();

//change the size of the Chessboard
function drawChessboard(size = 6){
    for (let i = 0; i < size; i++) {
        let row = '';
        for (let j = 0; j < size; j++) {
          if ((i + j) % 2 === 0) {
            row += '#';
          } else {
            row += ' ';
          }
        }
        console.log(row);
  }
}

drawChessboard(10);

//change the pattern of the Chessboard
function drawChessboard(size = 4, pattern = '&',pattern2='*'){
    for (let i = 0; i < size; i++) {
        let row = '';
        for (let j = 0; j < size; j++) {
          if ((i + j) % 2 === 0) {
            row += pattern;
          } else {
            row += pattern2;
          }
        }
        console.log(row);
  }
}

drawChessboard(3,'^','@');